class User < ApplicationRecord
	has_many :facts
end
