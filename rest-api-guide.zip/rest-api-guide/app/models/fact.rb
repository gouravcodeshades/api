class Fact < ApplicationRecord
  belongs_to :user
end
